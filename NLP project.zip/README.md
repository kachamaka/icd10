# Information Retrieval Project - ICD10 Codes

## This project is for the Information Retrieval course

### BUILD command for ubuntu/amd64

```GOOS=linux GOARCH=amd64 CGO_ENABLED=0 go build -o ./bin/icd10.exe```
